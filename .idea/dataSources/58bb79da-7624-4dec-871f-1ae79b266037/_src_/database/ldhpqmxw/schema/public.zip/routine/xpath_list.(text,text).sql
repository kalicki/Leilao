create function xpath_list(text, text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT xpath_list($1,$2,',')
$$;
