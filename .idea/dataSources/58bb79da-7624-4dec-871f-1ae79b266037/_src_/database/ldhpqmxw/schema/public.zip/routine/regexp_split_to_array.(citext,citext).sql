create function regexp_split_to_array(citext, citext) returns text[]
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT pg_catalog.regexp_split_to_array( $1::pg_catalog.text, $2::pg_catalog.text, 'i' );
$$;
