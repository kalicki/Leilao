create function xpath_nodeset(text, text, text) returns text
IMMUTABLE
LANGUAGE SQL
AS $$
SELECT xpath_nodeset($1,$2,'',$3)
$$;
